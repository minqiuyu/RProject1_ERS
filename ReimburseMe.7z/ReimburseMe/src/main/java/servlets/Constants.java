package servlets;

public class Constants {
	
	public static final String currentUserSessionAttributeName = "currentuser";

}
