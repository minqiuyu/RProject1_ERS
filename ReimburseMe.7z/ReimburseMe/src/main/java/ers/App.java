package ers;

import java.util.ArrayList;
import java.util.List;
import org.mindrot.jbcrypt.BCrypt;

import dao.ReimbursementDAO;
import data.Reimbursement;

public class App {
	
    public static void main( String[] args ) {
    	
    	List<String> pwList = createPwList();
    	hashPw(pwList);
    	
    	/*
    	ReimbursementDAO reimbDAO = new ReimbursementDAO();
    	List<Reimbursement> reimbList = reimbDAO.getReimbursementList(null, null);
    	
    	reimbList = reimbDAO.getReimbursementList((short)2, 1);
    	
    	for (int i = 0; i < reimbList.size(); i++) {
    		System.out.println(reimbList.get(i).getReimbursementDescription());
    	}
    	
    	Reimbursement reimb = reimbDAO.getReimbursementById(3);
    	
    	System.out.println(reimb.getReimbursementDescription());
    	*/
    }
    
    public static List<String> createPwList() {
    	List<String> pwList = new ArrayList<String>();
    
    	pwList.add("adminpass");
    	pwList.add("password");
    	pwList.add("anotherpassword");
    	
    	return pwList;
    }
    
    public static void hashPw(List<String> pwList) {
    	
    	for (String pw : pwList) {
    		String pwHash = BCrypt.hashpw(pw, BCrypt.gensalt()); 
        	System.out.println(pwHash);
    	}
    }
}
